import urllib.request
from lxml import etree
import re 
import time
from functools import reduce
import xlwt

#获得页面数据
def get_page(myword):
    basurl='http://cn.bing.com/dict/search?q='
    searchurl=basurl+myword
    response =  urllib.request.urlopen(searchurl)  
    html = response.read()
    return html

#获得单词释义
def get_chitiao(html_selector):
    chitiao=[]
    hanyi_xpath='/html/body/div[1]/div/div/div[1]/div[1]/ul/li'
    get_hanyi=html_selector.xpath(hanyi_xpath)
    for item in get_hanyi:
        it=item.xpath('span')
        chitiao.append('%s||%s'%(it[0].text,it[1].xpath('span')[0].text))
    if len(chitiao)>0:
        return reduce(lambda x, y:"%s||||%s"%(x,y),chitiao)
    else:
        return "*"



#获得单词音标AE
def get_yinbiao_AE(html_selector):
    yingbiao=[]
    yingbiao_xpath='/html/body/div[1]/div/div/div[1]/div[1]/div[1]/div[2]/div'
    bbb="(https\:.*?mp3)"
    reobj1=re.compile(bbb,re.I|re.M|re.S)
    get_yingbiao=html_selector.xpath(yingbiao_xpath)
    for item in get_yingbiao:
        it=item.xpath('div')
        if len(it)>0:
            yingbiao.append(it[0].text)
    if len(yingbiao)>0:
        return reduce(lambda x, y:"%s||||%s"%(x,y),yingbiao)
    else:
        return "*"

#获得单词音标BE
def get_yinbiao_BE(html_selector):
    yingbiao=[]
    yingbiao_xpath='/html/body/div[1]/div/div/div[1]/div[1]/div[1]/div[2]/div'
    bbb="(https\:.*?mp3)"
    reobj1=re.compile(bbb,re.I|re.M|re.S)
    get_yingbiao=html_selector.xpath(yingbiao_xpath)
    for item in get_yingbiao:
        it=item.xpath('div')
        if len(it)>0:
            yingbiao.append(it[2].text)
    if len(yingbiao)>0:
        return reduce(lambda x, y:"%s||||%s"%(x,y),yingbiao)
    else:
        return "*"

#获得单词读音AE
def get_duyin_AE(html_selector):
    yingbiao=[]
    yingbiao_xpath='/html/body/div[1]/div/div/div[1]/div[1]/div[1]/div[2]/div'
    bbb="(https\:.*?mp3)"
    reobj1=re.compile(bbb,re.I|re.M|re.S)
    get_yingbiao=html_selector.xpath(yingbiao_xpath)
    for item in get_yingbiao:
        it=item.xpath('div')
        if len(it)>0:
            ddd=reobj1.findall(it[1].xpath('a')[0].get('onmouseover',None))
            yingbiao.append(ddd[0])
    if len(yingbiao)>0:
        return reduce(lambda x, y:"%s||||%s"%(x,y),yingbiao)
    else:
        return "*"

#获得单词读音BE
def get_duyin_BE(html_selector):
    yingbiao=[]
    yingbiao_xpath='/html/body/div[1]/div/div/div[1]/div[1]/div[1]/div[2]/div'
    bbb="(https\:.*?mp3)"
    reobj1=re.compile(bbb,re.I|re.M|re.S)
    get_yingbiao=html_selector.xpath(yingbiao_xpath)
    for item in get_yingbiao:
        it=item.xpath('div')
        if len(it)>0: 
            ddd=reobj1.findall(it[3].xpath('a')[0].get('onmouseover',None))
            yingbiao.append(ddd[0])
    if len(yingbiao)>0:
        return reduce(lambda x, y:"%s||||%s"%(x,y),yingbiao)
    else:
        return "*"

#获得例句英语
def get_liju_e(html_selector):
    liju=[]
    get_liju_e=html_selector.xpath('//*[@class="val_ex"]')
    get_liju_cn=html_selector.xpath('//*[@class="bil_ex"]')
    get_len=len(get_liju_e)
    if get_len>0:
        liju.append(get_liju_e[0].text)
    
    if len(liju)>0:
        return reduce(lambda x, y:"%s||||%s"%(x,y),liju)
    else:
        return "*"

#获得例句汉语
def get_liju_cn(html_selector):
    liju=[]
    get_liju_e=html_selector.xpath('//*[@class="val_ex"]')
    get_liju_cn=html_selector.xpath('//*[@class="bil_ex"]')
    get_len=len(get_liju_cn)
    if get_len>0:
        liju.append(get_liju_cn[0].text)
    
    if len(liju)>0:
        return reduce(lambda x, y:"%s||||%s"%(x,y),liju)
    else:
        return "*"




filename='gre.txt'
f=open(filename,"r",encoding='utf-8',errors='ignore')
words=f.readlines()
f.close()

counter=0
workbook = xlwt.Workbook()
sheet = workbook.add_sheet("wordlist")

sheet.write(counter,0,'word')
sheet.write(counter,1,'yisi')
sheet.write(counter,2,'yinbiao_AE')
sheet.write(counter,3,'yinbiao_BE')
sheet.write(counter,4,'duyin_AE')
sheet.write(counter,5,'duyin_BE')
sheet.write(counter,6,'liju_e')
sheet.write(counter,7,'liju_cn')
counter=counter+1

for word in words:
    print(counter)
       #获得页面
    try:
        pagehtml=get_page(word)
        selector = etree.HTML(pagehtml.decode('utf-8'))
        #单词释义
        chitiao=get_chitiao(selector)
        #单词音标及读音
        yinbiao_AE=get_yinbiao_AE(selector)
        yinbiao_BE=get_yinbiao_BE(selector)
        duyin_AE=get_duyin_AE(selector)
        duyin_BE=get_duyin_BE(selector)

        liju_e=get_liju_e(selector)
        liju_cn=get_liju_cn(selector)

        sheet.write(counter,0,word)
        sheet.write(counter,1,chitiao)
        sheet.write(counter,2,yinbiao_AE)
        sheet.write(counter,3,yinbiao_BE)
        sheet.write(counter,4,duyin_AE)
        sheet.write(counter,5,duyin_BE)
        sheet.write(counter,6,liju_e)
        sheet.write(counter,7,liju_cn)
        counter=counter+1
    except:
        pass
    continue
    
workbook.save('gre.xls')
    
