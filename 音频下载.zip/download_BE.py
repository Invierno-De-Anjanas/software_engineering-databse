import xlrd
import requests

workbook=xlrd.open_workbook("gaokao.xls")

BE=workbook.sheet_by_name("BE")

row=1
while row <3415:
  my_word=BE.cell_value(row,0)
  my_url=BE.cell_value(row,1)
  if my_url=='*':
    row=row+1
    continue
  r=requests.get(my_url)
  file_name=my_word+'_BE'
  file_name=file_name.replace('\n','')
  
  print(row)
  with open("%s.mp3"%(file_name),'wb') as f:
    f.write(r.content)
  f.close()
  row=row+1

